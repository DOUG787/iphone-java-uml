public class Main {
    public static void main(String[] args) {
        iPhone meuIPhone = new iPhone();

        // Usando o reprodutor musical
        meuIPhone.selecionarMusica("Bohemian Rhapsody - Queen");
        meuIPhone.tocar();
        meuIPhone.pausar();

        // Usando o telefone
        meuIPhone.ligar("11987654321");
        meuIPhone.atender();
        meuIPhone.iniciarCorreioVoz();

        // Usando o navegador
        meuIPhone.exibirPagina("https://openai.com");
        meuIPhone.adicionarNovaAba();
        meuIPhone.atualizarPagina();
    }
}
