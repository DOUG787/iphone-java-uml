# Projeto: Modelagem UML e Implementação em Java - iPhone

Este projeto simula um iPhone com funcionalidades de:
- Reprodutor Musical
- Aparelho Telefônico
- Navegador na Internet

As funcionalidades foram separadas em interfaces distintas e implementadas na classe `iPhone`.

## 📚 Diagrama UML

```mermaid
classDiagram
    class ReprodutorMusical {
        +tocar()
        +pausar()
        +selecionarMusica(String musica)
    }

    class AparelhoTelefonico {
        +ligar(String numero)
        +atender()
        +iniciarCorreioVoz()
    }

    class NavegadorInternet {
        +exibirPagina(String url)
        +adicionarNovaAba()
        +atualizarPagina()
    }

    class iPhone {
        +tocar()
        +pausar()
        +selecionarMusica(String musica)
        +ligar(String numero)
        +atender()
        +iniciarCorreioVoz()
        +exibirPagina(String url)
        +adicionarNovaAba()
        +atualizarPagina()
    }

    iPhone --> ReprodutorMusical
    iPhone --> AparelhoTelefonico
    iPhone --> NavegadorInternet
```

## 📁 Estrutura do Projeto

```
src/
├── ReprodutorMusical.java
├── AparelhoTelefonico.java
├── NavegadorInternet.java
└── iPhone.java
```

## 🛠️ Tecnologias
- Java
- MermaidJS (para o diagrama)

## ▶️ Exemplo de Uso (`Main.java`)

```java
public class Main {
    public static void main(String[] args) {
        iPhone meuIPhone = new iPhone();

        meuIPhone.selecionarMusica("Bohemian Rhapsody - Queen");
        meuIPhone.tocar();
        meuIPhone.pausar();

        meuIPhone.ligar("11987654321");
        meuIPhone.atender();
        meuIPhone.iniciarCorreioVoz();

        meuIPhone.exibirPagina("https://openai.com");
        meuIPhone.adicionarNovaAba();
        meuIPhone.atualizarPagina();
    }
}
```

## 🚀 Instruções para executar

1. Compile os arquivos `.java`:
```bash
javac *.java
```

2. Execute o programa:
```bash
java Main
```

## 📢 Observação
- Você pode melhorar o projeto criando pacotes (`package`) para organizar ainda melhor o código.
